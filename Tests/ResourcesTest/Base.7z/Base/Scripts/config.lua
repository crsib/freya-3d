--Configuration file
module ( ..., package.seeall )
--window properties
window = {
	width = 1024,
	height = 768,
	bpp = 32,
	fullscreen = 0,
	caption = "Deferred test"
}

Renderer = {
	GBufferSize 	 = 1024, --both size for g-buffer and cubemap side
	ShadowBufferSize = 1024, --size of shadow buffer texture
	FarPlaneDistance = 1000, --distance of the far plane
	Deferred2	 = {vertex="/Shaders/Vertex/BasicDeferredOut.vert",fragment="/Shaders/Fragment/BasicDeferredOut.frag"},
}
