--Run file
print("executed")
Include("/Scripts/STD/input.lua","input")
Include("/Scripts/config.lua","config")
Include("/Scripts/test.lua","test")
print("All included")
--controllers
--fly camera
local FlyCam
local RotateCam

function FlyCameraBasicKeyboard(UserDataArray,SizeOfArray)
	kbd.arr:Bind(UserDataArray)
	local action = input_config.KeyboardBasicActions[1]
	if kbd.CheckKey(action.Up.primary_key) then --up pressed
		FlyCam:MoveUp(0.05)
	end
	if kbd.CheckKey(action.Down.primary_key) then --up pressed
		FlyCam:MoveDown(0.05)
	end
	if kbd.CheckKey(action.Fwd.primary_key) then --up pressed
		FlyCam:MoveForward(0.08)
	end
	if kbd.CheckKey(action.Back.primary_key) then --up pressed
		FlyCam:MoveBackward(0.2)
	end
	if kbd.CheckKey(action.StrafeLeft.primary_key) then --up pressed
		FlyCam:MoveLeft(0.08)
	end
	if kbd.CheckKey(action.StrafeRight.primary_key) then --up pressed
		FlyCam:MoveRight(0.08)
	end
end

function FlyCameraMouse(UserDataArray,SizeOfArray)
	mouse.arr:Bind(UserDataArray)
	local dx,dy,leftBtn,rightBtn,clickWheel,rotateWheel = mouse.ProcessOutput()
	FlyCam:ChangeYaw(-dx*0.0000390625)
	FlyCam:ChangePitch(-dy*0.0000390625)
	
end

--rotate camera
function RotateCameraBasicKeyboard(UserDataArray,SizeOfArray)
	kbd.arr:Bind(UserDataArray)
	local action = input_config.KeyboardBasicActions[2]
	if kbd.CheckKey(action.RotateYCCW.primary_key) then
		RotateCam:ChangeYaw(-0.03)
	end
	if kbd.CheckKey(action.RotateYCW.primary_key) then
		RotateCam:ChangeYaw(0.03)
	end
	if kbd.CheckKey(action.RotateXCCW.primary_key) then
		RotateCam:ChangePitch(0.03)
	end
	if kbd.CheckKey(action.RotateXCW.primary_key) then
		RotateCam:ChangePitch(-0.03)
	end
end

function RotateCameraMouse(UserDataArray,SizeOfArray)

end

--generic

function ExitDemo()
	StopEngine()
end
local ActiveCamera = 0
function ChangeCamera()
	if ActiveCamera == 0 then ActiveCamera = 1 else ActiveCamera = 0 end
	renderer.Renderer.Cameras:SetActiveCamera(ActiveCam/era)
	input.ChangeMode(ActiveCamera+1)
end

local Grab = 0;
function GrabInput()
	if Grab == 0 then 
		Grab = 1 
		input.GrabInput()
	else 
		Grab = 0 
		input.ReleaseInput()
	end
end;
------------------------------------------------------------------------------------------------

input.Init(1)
CreateWindow(config.window.width,config.window.height,config.window.bpp,config.window.fullscreen)
SetCaption(config.window.caption)
------------------------------Cameras setup-----------------------------------------------------
local Pos = math.vector3d:new(5.0,0.1,5.0)
local Dir	   = math.vector3d:new(-1.0,-0.0,-1.0)
local Up	   = math.vector3d:new(0,1.0,0)
local scale    = config.window.width/config.window.height
local ActiveCamera = 0
FlyCam = cameras.FlyCamera:new(Pos,Dir,Up,1.04,scale,1.0,1000.0)
RotateCam = cameras.RotateCamera:new(Pos,Dir,Up,1.04,scale,1.0,1000.0)

------------------------------------------------------------------------------------------------
--Adding cameras
renderer.Renderer.Cameras:AddCamera(FlyCam)
renderer.Renderer.Cameras:AddCamera(RotateCam)
--Start
StartEngine()
DestroyWindow()
