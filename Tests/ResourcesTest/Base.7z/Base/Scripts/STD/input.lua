module(...,package.seeall)
----------------------------------------------------------------------------------------------------------------------

--rebinding code
----------------------------------------------------------------------------------------------------------------------
Keyboard = {
--usorted
	Escape 		= {primary = _input_internal_.SDLK_ESCAPE},
	Return 		= {primary = _input_internal_.SDLK_RETURN,secondary=SDLK_KP_ENTER},
	Tab			= {primary = _input_internal_.SDLK_TAB},
	Backspace	= {primary = _input_internal_.SDLK_BACKSPACE},
	Pause		= {primary = _input_internal_.SDLK_PAUSE},
	Space		= {primary = _input_internal_.SDLK_SPACE},
	Minus		= {primary = _input_internal_.SDLK_MINUS},
	Equals		= {primary = _input_internal_.SDLK_EQUALS},
--digits
	Zero		= {primary = _input_internal_.SDLK_0,secondary = _input_internal_.SDLK_RIGHTPAREN},
	One			= {primary = _input_internal_.SDLK_1,secondary = _input_internal_.SDLK_EXCLAIM},
	Two			= {primary = _input_internal_.SDLK_2,secondary = _input_internal_.SDLK_AT},
	Three		= {primary = _input_internal_.SDLK_3,secondary = _input_internal_.SDLK_HASH},
	Four		= {primary = _input_internal_.SDLK_4,secondary = _input_internal_.SDLK_DOLLAR},
	Five		= {primary = _input_internal_.SDLK_5},
	Six			= {primary = _input_internal_.SDLK_6},
	Seven		= {primary = _input_internal_.SDLK_7,secondary = _input_internal_.SDLK_AMPERSAND},
	Eight		= {primary = _input_internal_.SDLK_8,secondary = _input_internal_.SDLK_ASTERISK},
	Nine		= {primary = _input_internal_.SDLK_9,secondary = _input_internal_.SDLK_LEFTPAREN},
--numeric
	NUM0 		= {primary = _input_internal_.SDLK_KP0},
	NUM1 		= {primary = _input_internal_.SDLK_KP1},
	NUM2 		= {primary = _input_internal_.SDLK_KP2},
	NUM3 		= {primary = _input_internal_.SDLK_KP3},
	NUM4 		= {primary = _input_internal_.SDLK_KP4},
	NUM5 		= {primary = _input_internal_.SDLK_KP5},
	NUM6 		= {primary = _input_internal_.SDLK_KP6},
	NUM7 		= {primary = _input_internal_.SDLK_KP7},
	NUM8 		= {primary = _input_internal_.SDLK_KP8},
	NUM9 		= {primary = _input_internal_.SDLK_KP9},
	NUMPeriod	= {primary = _input_internal_.SDLK_KP_PERIOD},
	NUMDivide	= {primary = _input_internal_.SDLK_KP_DIVIDE},
	NUMMultiply	= {primary = _input_internal_.SDLK_KP_MULTIPLY},
	NUMMinus	= {primary = _input_internal_.SDLK_KP_MINUS},
	NUMPlus		= {primary = _input_internal_.SDLK_KP_PLUS},
	NUMEquals	= {primary = _input_internal_.SDLK_KP_EQUALS},
-- Arrows + Home/End pad
	Up			= {primary = _input_internal_.SDLK_UP},
	Down		= {primary = _input_internal_.SDLK_DOWN},
	Right		= {primary = _input_internal_.SDLK_RIGHT},
	Left		= {primary = _input_internal_.SDLK_LEFT},
	Insert		= {primary = _input_internal_.SDLK_INSERT},
	Home		= {primary = _input_internal_.SDLK_HOME},
	End			= {primary = _input_internal_.SDLK_END},
	PageUp		= {primary = _input_internal_.SDLK_PAGEUP},
	PageDown	= {primary = _input_internal_.SDLK_PAGEDOWN},
	Delete		= {primary = _input_internal_.SDLK_DELETE},

-- Function keys 
	F1			= {primary = _input_internal_.SDLK_F1},
	F2			= {primary = _input_internal_.SDLK_F2},
	F3			= {primary = _input_internal_.SDLK_F3},
	F4			= {primary = _input_internal_.SDLK_F4},
	F5			= {primary = _input_internal_.SDLK_F5},
	F6			= {primary = _input_internal_.SDLK_F6},
	F7			= {primary = _input_internal_.SDLK_F7},
	F8			= {primary = _input_internal_.SDLK_F8},
	F9			= {primary = _input_internal_.SDLK_F9},
	F10			= {primary = _input_internal_.SDLK_F10},
	F11			= {primary = _input_internal_.SDLK_F11},
	F12			= {primary = _input_internal_.SDLK_F12},
	F13			= {primary = _input_internal_.SDLK_F13},
	F14			= {primary = _input_internal_.SDLK_F14},
	F15			= {primary = _input_internal_.SDLK_F15},

--Key state modifier keys
	NumLock		= {primary = _input_internal_.SDLK_NUMLOCK},
	CapsLock	= {primary = _input_internal_.SDLK_CAPSLOCK},
	ScrollLock	= {primary = _input_internal_.SDLK_SCROLLOCK},
	RightShift	= {primary = _input_internal_.SDLK_RSHIFT},
	LeftShift	= {primary = _input_internal_.SDLK_LSHIFT},
	RightCtrl	= {primary = _input_internal_.SDLK_RCTRL},
	LeftCtrl	= {primary = _input_internal_.SDLK_LCTRL},
	RightAlt	= {primary = _input_internal_.SDLK_RALT},
	LeftAlt		= {primary = _input_internal_.SDLK_LALT},
	RightMeta	= {primary = _input_internal_.SDLK_RMETA},
	LeftMeta	= {primary = _input_internal_.SDLK_LMETA},
	LeftSuper	= {primary = _input_internal_.SDLK_LSUPER},
	RigthSuper	= {primary = _input_internal_.SDLK_RSUPER},
	AltGr		= {primary = _input_internal_.SDLK_MODE},

--Miscellaneous function keys */
	SysReq		= {primary = _input_internal_.SDLK_SYSREQ},
	Break		= {primary = _input_internal_.SDLK_BREAK},
--letters
	A			= {primary = _input_internal_.SDLK_a , secondary = _input_internal_.SDLK_WORLD_0},
	B			= {primary = _input_internal_.SDLK_b , secondary = _input_internal_.SDLK_WORLD_10},
	C			= {primary = _input_internal_.SDLK_c , secondary = _input_internal_.SDLK_WORLD_8},
	D			= {primary = _input_internal_.SDLK_d , secondary = _input_internal_.SDLK_WORLD_2},
	E			= {primary = _input_internal_.SDLK_e , secondary = _input_internal_.SDLK_WORLD_13},
	F			= {primary = _input_internal_.SDLK_f , secondary = _input_internal_.SDLK_WORLD_3},
	G			= {primary = _input_internal_.SDLK_g , secondary = _input_internal_.SDLK_WORLD_5},
	H			= {primary = _input_internal_.SDLK_h , secondary = _input_internal_.SDLK_WORLD_4},
	I			= {primary = _input_internal_.SDLK_i , secondary = _input_internal_.SDLK_WORLD_21},
	J			= {primary = _input_internal_.SDLK_j , secondary = _input_internal_.SDLK_WORLD_24},
	K			= {primary = _input_internal_.SDLK_k , secondary = _input_internal_.SDLK_WORLD_26},
	L			= {primary = _input_internal_.SDLK_l , secondary = _input_internal_.SDLK_WORLD_23},
	M			= {primary = _input_internal_.SDLK_m , secondary = _input_internal_.SDLK_WORLD_31},
	N			= {primary = _input_internal_.SDLK_n , secondary = _input_internal_.SDLK_WORLD_30},
	O			= {primary = _input_internal_.SDLK_o , secondary = _input_internal_.SDLK_WORLD_18},
	P			= {primary = _input_internal_.SDLK_p , secondary = _input_internal_.SDLK_WORLD_22},
	Q			= {primary = _input_internal_.SDLK_q , secondary = _input_internal_.SDLK_WORLD_11},
	R			= {primary = _input_internal_.SDLK_r , secondary = _input_internal_.SDLK_WORLD_14},
	S			= {primary = _input_internal_.SDLK_s , secondary = _input_internal_.SDLK_WORLD_1},
	T			= {primary = _input_internal_.SDLK_t , secondary = _input_internal_.SDLK_WORLD_16},
	U			= {primary = _input_internal_.SDLK_u , secondary = _input_internal_.SDLK_WORLD_19},
	V			= {primary = _input_internal_.SDLK_v , secondary = _input_internal_.SDLK_WORLD_9},
	W			= {primary = _input_internal_.SDLK_w , secondary = _input_internal_.SDLK_WORLD_12},
	X			= {primary = _input_internal_.SDLK_x , secondary = _input_internal_.SDLK_WORLD_7},
	Y			= {primary = _input_internal_.SDLK_y , secondary = _input_internal_.SDLK_WORLD_15},
	Z			= {primary = _input_internal_.SDLK_z , secondary = _input_internal_.SDLK_WORLD_6},
-- other
	Less		= {primary = _input_internal_.SDLK_COMMA, secondary =  SDLK_WORLD_29},
	Greater		= {primary = _input_internal_.SDLK_PERIOD, secondary = SDLK_WORLD_32},
	Slash		= {primary = _input_internal_.SDLK_SLASH},
	Backslash	= {primary = _input_internal_.SDLK_BACKSLASH , secondary = _input_internal_.SDLK_WORLD_28},
	Qoute		= {primary = _input_internal_.SDLK_QOUTE , secondary = _input_internal_.SDLK_WORLD_25},
	Semicolon	= {primary = _input_internal_.SDLK_SEMICOLON , secondary = _input_internal_.SDLK_WORLD_27},
	Tilda		= {primary = _input_internal_.SDLK_RIGHTBRACKET},
	RightBracket= {primary = _input_internal_.SDLK_RIGHTBRACKET , secondary = _input_internal_.SDLK_WORLD_17},
	LeftBracket	= {primary = _input_internal_.SDLK_LEFTBRACKET , secondary = _input_internal_.SDLK_WORLD_20}
}
------------------------------------------------------------------------------------------------------------------------
--real proc setting code
Mouse = {
	Left 		= 4,
	Right		= 5,
	Middle		= 6,
	WheelUp		= 7,
	WheelDown	= 8	
}
------------------------------------------------------------------------------------------------------------------------
--input grab/release
------------------------------------------------------------------------------------------------------------------------
function GrabInput()
	_input_internal_.INPUT:GrabInput()
end

function ReleaseInput()
	_input_internal_.INPUT:ReleaseInput()
end
-------------------------------------------------------------------------------------------------------------------------
--keyboard
-------------------------------------------------------------------------------------------------------------------------
function SetKeyHandler(id,proc,dtime) --sets a proc for key
	if dtime == nil then dtime=0 end
	if id.primary then _input_internal_.INPUT[0]:RegisterHandler(id.primary,proc,dtime) end
	if id.secondary then _input_internal_.INPUT[0]:RegisterHandler(id.secondary,proc,dtime) end
end
-------------------------------------------------------------------------------------------------------------------------
function SetBasicKeyboardHandler(handler)
	_input_internal_.INPUT[0]:SetBasicHandler(handler)	--calls keyboard method
end
-------------------------------------------------------------------------------------------------------------------------
function UnsetKeyHadler(id)	--uregistres a key
	if id.primary then _input_internal_.INPUT[0]:UnregisterHandler(id.primary) end
	if id.secondary then _input_internal_.INPUT[0]:UnregisterHandler(id.secondary) end
end
-------------------------------------------------------------------------------------------------------------------------

--mouse
-------------------------------------------------------------------------------------------------------------------------
function SetMouseHandler(handler)
	_input_internal_.INPUT[1]:SetBasicHandler(handler)
end
-------------------------------------------------------------------------------------------------------------------------
function SetMouseButtonHandler(num,proc)
	_input_internal_.INPUT[1]:RegisterHandler(num,proc,0)
end

-------------------------------------------------------------------------------------------------------------------------

function UnsetMouseButtonHandler(id)
	_input_internal_.INPUT[1]:UnregisterHandler(id)
 end
	

--input structures and modules

Include("/Scripts/STD/Keyboard.lua","kbd");
Include("/Scripts/STD/Mouse.lua","mouse");

--Some help info. It seems I should document it somewhere else

--[[
--all arrays must have 0 or same number of modes 

--This array contains table of actions for each mode and handlers of each mode
--table of atction is { [action name] = {primary_key=[],secondary_key=[],description="[]"}
--secondary key might be ommited
--each mode table (except generic(if exists) must have field 'controller' with function name to call
KeyboardBasicActions = {
	 1 = {},
	 2 = {},
	 generic = {}
}

--this array consists of { [action name] = {primary_key=[],secondary_key=[],description="[]" ,sleep=[],controller=[]}
--NB!! in this case - controller is a string name
KeyboardHandledActions = {
	 1 = {},
	 2 = {},
	 generic = {}
}
--this array contains table of mouse basic procs for different modes
MouseBasicActions = {
	1 = {},
	2 = {}
}
or
MouseBasicActions = {
	generic = {}	
}

--this array is pretty identical to KeyboardHandledActions, but for mouse buttons (with scrolling support)
--primary_key is named button and there is not sleep time
MouseHandledActions = {
	 1 = {},
	 2 = {},
	 generic = {}
}
]]

Include("/Scripts/input_config.lua","input_config");

local InputMode = 0 -- for generic
--this function will possibly change mode of input unit
function ChangeMode(newMode)
	local oldMode = InputMode
	--now try to reset everything.
	if oldMode ~= 0 then --unregister actions
		if input_config.KeyboardHandledActions[oldMode] then
			for name,array in pairs(input_config.KeyboardBasicActions[oldMode]) do
				UnsetKeyHandler(array.primary_key)
				UnsetKeyHandler(array.secondary_key)	
			end
		end
		if input_config.MouseHandledActions[oldMode] then
			for name,array in pairs(input_config.MouseBasicActions[oldMode]) do
				UnsetKeyHandler(array.button)
			end
		end
	end
	--Now set them back up
	if newMode ~= 0 then
		--now, try to set handlers
		if input_config.KeyboardHandledActions[newMode] then
			for name,array in pairs(input_config.KeyboardBasicActions[newMode]) do
				SetKeyHandler(array.primary_key,array.controller,array.sleep)
				if array.secondary_key then
					SetKeyHandler(array.secondary_key,array.controller,array.sleep)
				end
			end
		end
		if input_config.MouseHandledActions[newMode] then
			for name,array in pairs(input_config.MouseHandledActions[newMode]) do
				SetMouseButtonHandler(array.button,array.controller)
			end
		end
	end
	--now,try to set new basic handlers
	if newMode ~= 0 then
		if input_config.KeyboardBasicActions then 
			if  input_config.KeyboardBasicActions[newMode] then
				SetBasicKeyboardHandler(input_config.KeyboardBasicActions[newMode].controller);
			end
		end
		if input_config.MouseBasicActions then
			if input_config.MouseBasicActions[newMode] then
				SetMouseHandler(input_config.MouseBasicActions[newMode])
			end
		end
	end
	--now swap modes
	InputMode = mode;
	return oldMode, newMode
end
--this will set all the generic controllers
function SetGenericHandlers()
	if input_config.KeyboardHandledActions.generic then
		for name,array in pairs(input_config.KeyboardHandledActions.generic) do
			SetKeyHandler(array.primary_key,array.controller,array.sleep)
			if array.secondary_key then
				SetKeyHandler(array.secondary_key,array.controller,array.sleep)
			end
		end
	end
	if input_config.MouseHandledActions.generic then
		for name,array in pairs(input_config.MouseHandledActions.generic) do
			SetMouseButtonHandler(array.button,array.controller)
		end
	end
	if input_config.MouseBasicActions.generic then
		input_config.SetMouseHanler(MouseBasicActions.generic)
	end
end

--This will init base input i.e. kbd and mouse

function Init(mode)
	SetGenericHandlers()
	ChangeMode(mode)
end


