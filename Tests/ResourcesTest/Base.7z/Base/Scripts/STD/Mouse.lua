module(...,package.seeall)

arr = CArray_char_()

function ProcessOutput()
	local sgn
	if arr[0] == 0 then sgn = 1 else sgn = -1 end
	local x = arr[1]*sgn
	if arr[2] == 0 then sgn = 1 else sgn = -1 end
	local y = arr[3]*sgn
	
	local leftBtn
	local rightBtn
	local clickWheel
	local rotateWheel
	if arr[4] == 0 then leftBtn = false else leftBtn = true end
	if arr[5] == 0 then rightBtn = false else rightBtn = true end
	if arr[6] == 0 then clickWheel = false else clickWheel = true end
	if arr[7] == 0 then rotateWheel = 1 end
	if arr[7] == 0 then rotateWheel = -1 end
	return x,y,leftBtn,rightBtn,clickWheel,rotateWheel
end