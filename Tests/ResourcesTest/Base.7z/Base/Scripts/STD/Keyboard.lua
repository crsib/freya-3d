module(...,package.seeall)

arr = CArray_char_()

function CheckKey(key)
	return (arr[key.primary] == 1) or (arr[key.secondary] == 1)
end
