module(...,package.seeall)
--This array contains table of actions for each mode and handlers of each mode
--table of atction is { [action name] = {primary_key=[],secondary_key=[],description="[]"}
--secondary key might be ommited
--each mode table (except generic(if exists) must have field 'controller' with function(UserDataArray,SizeOfArray)
KeyboardBasicActions = {
	 	   {controller = "FlyCameraBasicKeyboard",
	 		Fwd  = {primary_key=input.Keyboard.W, secondary_key=input.Keyboard.O,description="Forward"},
	 		Back = {primary_key=input.Keyboard.S, secondary_key=input.Keyboard.L,description="Back"},
	 		StrafeLeft = {primary_key=input.Keyboard.A,description="Strafe left"},
	 		StrafeRight = {primary_key=input.Keyboard.D,description="Strafe right"},
	 		Down = {primary_key=input.Keyboard.Down,description="Down"},
	 		Up  = {primary_key=input.Keyboard.Up,description="Up"}
	 	   },	--fly camera
	      {controller = "RotateCameraBasicKeyboard",
	       RotateYCCW = {primary_key=input.Keyboard.Left},
	       RotateYCW = {primary_key=input.Keyboard.Right},
	       RotateXCCW = {primary_key=input.Keyboard.Up},
	       RotateXCW = {primary_key=input.Keyboard.Down}
	      }
}

--this array consists of { [action name] = {primary_key=[],secondary_key=[],description="[]" , controller=[],sleep=[]}
KeyboardHandledActions = {
	 generic = {
	 	Exit = {primary_key=input.Keyboard.Escape,description="Leave demo",controller="ExitDemo"},
	 	ChangeCamera = {primary_key=input.Keyboard.C,sleep=500,controller="ChangeCamera"},
		GrabInput    = {primary_key=input.Keyboard.G,sleep=1000,controller="GrabInput"}
	 	}
}
--this array contains table of mouse basic procs for different modes
MouseBasicActions = {
	"FlyCameraMouse",
	"RotateCameraMouse"
}

--this array is pretty identical to KeyboardHandledActions, but for mouse buttons (with scrolling support)
MouseHandledActions = {
}
