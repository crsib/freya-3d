module ( ..., package.seeall )
function test()
	print("here from package")
	print("testing vectors")
	local vec1 = math.vector3d:new(1,0,0)
	local vec2 = math.vector3d:new(0,1,0)
	local vec4 = math["_vec3dADD"](vec1,vec2)
	local vec3 = vec1*3 + vec2 - vec4*vec1;
	local quat = math.quaternion:new(vec2,0.3)
	local q2 = math.quaternion:new()
	local r = quat*q2
	local q1 =  quat * vec3
	vec1:delete()
	vec2:delete()
end

--simple test fuction
function test_user_data(arg1,arg2)
	local arr = CArray_char_(arg1)
	print("arg " ..arr[0].. " count " .. arg2)
end